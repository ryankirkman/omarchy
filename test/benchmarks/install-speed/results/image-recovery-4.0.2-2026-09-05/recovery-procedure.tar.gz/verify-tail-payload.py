import gzip,hashlib,json,time
from pathlib import Path
source=Path('/run/image-recovery/tail-payload-checks.json.gz');data=json.loads(gzip.decompress(source.read_bytes()));root=Path('/run/image-recovery/mnt/omarchy-root')
started=time.monotonic();verified=0;total_bytes=0;errors=[]
for relative,expected in data['files'].items():
 file=root/relative
 try:
  if file.is_symlink() or not file.is_file():raise ValueError('expected regular file')
  digest=hashlib.sha256()
  with file.open('rb') as stream:
   while chunk:=stream.read(1024*1024):digest.update(chunk);total_bytes+=len(chunk)
  if digest.hexdigest()!=expected:raise ValueError('SHA256 mismatch')
  verified+=1
 except (OSError,ValueError) as error:errors.append({'path':relative,'error':str(error)})
result={'schema_version':1,'status':'verified' if not errors else 'failed','packages':data['packages'],'expected_regular_files':len(data['files']),'verified_regular_files':verified,'verified_bytes':total_bytes,'source_checks_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'excluded':data['excluded'],'elapsed_s':time.monotonic()-started,'errors':errors}
Path('/run/image-recovery/tail-payload-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if errors:raise SystemExit(1)
