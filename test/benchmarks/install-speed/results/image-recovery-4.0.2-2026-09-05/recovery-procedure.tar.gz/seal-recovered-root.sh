#!/bin/bash
set -euo pipefail
device=/dev/disk/by-id/virtio-OMARCHY_IMAGE_BUILD
mount_dir=/run/image-recovery/mnt
root=$mount_dir/omarchy-root
output=/run/image-recovered-output
[[ $(blkid -s UUID -o value "$device") == 51a18a79-7bde-4aeb-8895-181970407957 ]]
[[ -z $(lsblk -nro MOUNTPOINTS "$device" | tr -d '[:space:]') ]]
[[ ! -e $output/build-status.txt ]]
[[ $(systemctl show omarchy-image-recover -p Result --value) == exit-code ]]
python - <<'CHECK'
import json,re
from pathlib import Path
out=Path('/run/image-recovered-output')
events=[json.loads(line) for line in (out/'hook-replay.log').read_text().splitlines() if line.startswith('{')]
assert events[-1]=={'event':'all-hooks-complete','count':32}
assert all(x['returncode']==0 for x in events if x['event']=='hook-finished')
text=(out/'image-package-files.txt').read_text()
missing=set(re.findall(r'warning: \S+: /run/image-recovery/mnt/omarchy-root/(.*?) \(No such file or directory\)',text))
assert missing=={'var/log/cups/','var/log/old/','var/log/journal/','etc/resolv.conf'},missing
CHECK
stop_agents() { gpgconf --homedir "$root/etc/pacman.d/gnupg" --kill all 2>/dev/null || true; }
cleanup() { status=$?; set +e; stop_agents; if mountpoint -q "$mount_dir"; then umount -R "$mount_dir"; fi; exit "$status"; }
trap cleanup EXIT
mount -o compress-force=zstd:15 "$device" "$mount_dir"
cp "$output/image-package-files.txt" "$output/image-package-files-before-cleanup-fix.txt"
bsdtar -q -xpf /var/cache/omarchy/mirror/offline/cups-2:2.4.19-1-x86_64.pkg.tar.zst -C "$root" var/log/cups/
bsdtar -q -xpf /var/cache/omarchy/mirror/offline/filesystem-2025.10.12-1-any.pkg.tar.zst -C "$root" var/log/old/
bsdtar -q -xpf /var/cache/omarchy/mirror/offline/systemd-261.2-1-x86_64.pkg.tar.zst -C "$root" var/log/journal/
# Keep package-owned log directories; Qk must still validate the baked image.
# Empty unowned directories (including build-machine journal IDs) can go.
python - "$root" <<'PY'
import sys
from pathlib import Path
root = Path(sys.argv[1])
owned = set()
for record in (root / "var/lib/pacman/local").glob("*/files"):
    text = record.read_text()
    if "%FILES%\n" in text:
        owned.update(text.split("%FILES%\n", 1)[1].split("\n\n", 1)[0].splitlines())
for path in sorted((root / "var/log").rglob("*"), key=lambda p: len(p.parts), reverse=True):
    relative = path.relative_to(root).as_posix()
    if path.is_dir() and not path.is_symlink():
        if relative + "/" not in owned:
            path.rmdir()
    elif relative != "var/log/pacman.log":
        if relative in owned:
            if path.is_file() and not path.is_symlink():
                path.write_bytes(b"")
        else:
            path.unlink()
PY
rm -rf "$root/var/cache/pacman/pkg"/*
# filesystem owns this file. Restore its packaged default, not the live guest's
# resolver copied by pacstrap; deleting it leaves an incomplete package.
rm -f "$root/etc/resolv.conf"
cp -a "$root/usr/share/factory/etc/resolv.conf" "$root/etc/resolv.conf"

arch-chroot "$root" /usr/share/libalpm/scripts/systemd-hook tmpfiles
python /run/image-recovery/verify-recovery-database.py "$root" /run/image-recovery/archive-validation-checks.json.gz "$output/archive-database-verification-final.json"
pacman --root "$root" -Qk >"$output/image-package-files.txt" 2>&1
python /run/image-recovery/verify-tail-payload.py
cp /run/image-recovery/tail-payload-verification.json "$output/tail-payload-verification.json"
printf '%s\n' 'bd08eb3: preserve owned log paths and restore packaged resolver default; archive extraction repaired the four previously deleted paths, then tmpfiles policy was reapplied.' > "$output/cleanup-fix-provenance.txt"
sync
btrfs property set -ts "$root" ro true
read -r minimum _ < <(btrfs inspect-internal min-dev-size "$mount_dir")
alignment=$((256 * 1024 * 1024))
headroom=$((512 * 1024 * 1024))
image_size=$(((minimum + headroom + alignment - 1) / alignment * alignment))
btrfs filesystem resize "$image_size" "$mount_dir"
# QEMU must expose discard=unmap on this sparse build disk.
fstrim "$mount_dir"
sync
stop_agents
umount -R "$mount_dir"
btrfs check --readonly --check-data-csum "$device" >"$output/btrfs-check.txt" 2>&1
printf '%s\n' "$image_size" >"$output/raw-image-size.txt"
printf '%s\n' "${OMARCHY_IMAGE_COMPRESSION:-compress-force=zstd:15}" >"$output/btrfs-compression.txt"
printf '%s\n' 'BUILD_COMPLETE' >"$output/build-status.txt"
echo "Build complete: $image_size virtual bytes. Copy small output files, shut down this VM, then compress the raw disk on the host."
