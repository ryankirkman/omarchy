#!/usr/bin/python3
import hashlib,json,shlex,subprocess,sys,time
from pathlib import Path
root,plan_file,log_file=map(Path,sys.argv[1:])
plan=json.loads(plan_file.read_text())
for hook in plan['hooks']:
 if hashlib.sha256((root/hook['source']).read_bytes()).hexdigest()!=hook['sha256']:raise SystemExit('Hook source changed: '+hook['name'])
runner=r'''
import json,os,shlex,subprocess,sys,time
plan=json.load(sys.stdin)
os.environ['LC_ALL']='C'
os.chdir('/')
# libalpm performs this before transaction completion and before post-hooks.
subprocess.run(['/usr/bin/ldconfig'],check=True)
for hook in plan['hooks']:
 started=time.monotonic()
 print(json.dumps({'event':'hook-started','name':hook['name'],'exec':hook['exec'],'needs_targets':hook['needs_targets'],'target_count':len(hook['targets'])}),flush=True)
 result=subprocess.run(shlex.split(hook['exec']),input=''.join(x+'\n' for x in hook['targets']) if hook['needs_targets'] else '',text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 print(json.dumps({'event':'hook-finished','name':hook['name'],'returncode':result.returncode,'elapsed_s':time.monotonic()-started,'stdout':result.stdout,'stderr':result.stderr}),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
print(json.dumps({'event':'all-hooks-complete','count':len(plan['hooks'])}),flush=True)
'''
with log_file.open('w') as output:
 result=subprocess.run(['arch-chroot',str(root),'/usr/bin/python','-c',runner],input=json.dumps(plan),text=True,stdout=output,stderr=subprocess.STDOUT)
raise SystemExit(result.returncode)
