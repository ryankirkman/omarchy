#!/bin/bash
# One-off recovery of interrupted builder-01, not a fresh-build benchmark.
set -euo pipefail
device=/dev/disk/by-id/virtio-OMARCHY_IMAGE_BUILD
mount_dir=/run/image-recovery/mnt
root=$mount_dir/omarchy-root
bundle=/usr/local/lib/omarchy-benchmark/image-builder
baseline=/run/image-recovery/baseline
output=/run/image-recovered-output
[[ $(systemd-detect-virt --vm) =~ ^(qemu|kvm)$ ]]
[[ $(blkid -s UUID -o value "$device") == 51a18a79-7bde-4aeb-8895-181970407957 ]]
[[ $(blkid -s LABEL -o value "$device") == omarchy-root-image ]]
[[ -z $(lsblk -nro MOUNTPOINTS "$device" | tr -d '[:space:]') ]]
[[ $(systemctl show omarchy-image-precheck -p Result --value) == success ]]
[[ $(systemctl show omarchy-image-precheck -p ExecMainStatus --value) == 0 ]]
[[ ! -e $output ]]
[[ ! -e /run/image-recovery/recovery-started ]]
! pgrep -x pacman
[[ $(wc -l < "$baseline/package-manifest.txt") == 941 ]]
mkdir "$output"
touch /run/image-recovery/recovery-started
stop_agents() { gpgconf --homedir "$root/etc/pacman.d/gnupg" --kill all 2>/dev/null || true; }
cleanup() { status=$?; set +e; stop_agents; if mountpoint -q "$mount_dir"; then umount -R "$mount_dir"; fi; exit "$status"; }
trap cleanup EXIT
mount -o compress-force=zstd:15 "$device" "$mount_dir"
pacman --root "$root" -Q | LC_ALL=C sort > "$output/image-package-manifest.txt"
cmp "$baseline/package-manifest.txt" "$output/image-package-manifest.txt"
# Last installed package has no pending scriptlet. Previous scriptlets completed
# before the next package's installed event in this serialized transaction.
[[ $(cat /run/image-recovery/tail-repair/status.txt) == REPAIR_COMPLETE ]]
[[ $(systemctl show omarchy-image-tail-repair -p Result --value) == success ]]
python /run/image-recovery/plan-recovery-hooks.py "$root" "$output/hook-plan.json"
tar -C /run/image-recovery -czf "$output/tail-repair-evidence.tar.gz" tail-repair
cp /run/image-recovery/precheck.log "$output/pre-recovery-btrfs-check.txt"
cp /run/image-recovery/interrupted-pacman.log "$output/interrupted-pacman.log"
cp /run/image-recovery/pre-recovery-package-files.txt "$output/pre-recovery-package-files.txt"
cp /run/image-recovery/pre-recovery-package-manifest.txt "$output/pre-recovery-package-manifest.txt"
printf '%s\n' 'Recovered existing 941-package transaction after interrupted VM; completed all matching PostTransaction hooks before cleanup and validation.' > "$output/recovery-provenance.txt"
# No pacman exists in this newly booted guest; remove only the stale build lock.
rm -f "$root/var/lib/pacman/db.lck"
python /run/image-recovery/execute-recovery-hooks.py "$root" "$output/hook-plan.json" "$output/hook-replay.log"
stop_agents
rm -rf "$root/etc/pacman.d/gnupg"
: >"$root/etc/machine-id"
# openssh package should not seed keys, but an image must never share them.
rm -f "$root"/etc/ssh/ssh_host_*_key "$root"/etc/ssh/ssh_host_*_key.pub
find "$root/var/log" -mindepth 1 ! -name pacman.log -delete
rm -rf "$root/var/cache/pacman/pkg"/* "$root/etc/resolv.conf"

pacman --root "$root" -Q | LC_ALL=C sort >"$output/image-package-manifest.txt"
python "$bundle/validate-image-manifest.py" "$baseline" "$output"
mapfile -t installed < <(pacman --root "$root" -Qq)
mapfile -t explicit <"$output/image-explicit-packages.txt"
pacman --root "$root" -D --asdeps "${installed[@]}"
if (( ${#explicit[@]} > 0 )); then
  pacman --root "$root" -D --asexplicit "${explicit[@]}"
fi
pacman --root "$root" -Qqe | LC_ALL=C sort >"$output/image-explicit-packages-actual.txt"
cmp "$output/image-explicit-packages.txt" "$output/image-explicit-packages-actual.txt"
pacman --root "$root" -Qk >"$output/image-package-files.txt" 2>&1

sync
btrfs property set -ts "$root" ro true
read -r minimum _ < <(btrfs inspect-internal min-dev-size "$mount_dir")
alignment=$((256 * 1024 * 1024))
headroom=$((512 * 1024 * 1024))
image_size=$(((minimum + headroom + alignment - 1) / alignment * alignment))
btrfs filesystem resize "$image_size" "$mount_dir"
# QEMU must expose discard=unmap on this sparse build disk.
fstrim "$mount_dir"
sync
stop_agents
umount -R "$mount_dir"
btrfs check --readonly --check-data-csum "$device" >"$output/btrfs-check.txt" 2>&1
printf '%s\n' "$image_size" >"$output/raw-image-size.txt"
printf '%s\n' "${OMARCHY_IMAGE_COMPRESSION:-compress-force=zstd:15}" >"$output/btrfs-compression.txt"
printf '%s\n' 'BUILD_COMPLETE' >"$output/build-status.txt"
echo "Build complete: $image_size virtual bytes. Copy small output files, shut down this VM, then compress the raw disk on the host."
