#!/bin/bash
set -euo pipefail
device=/dev/disk/by-id/virtio-OMARCHY_IMAGE_BUILD
mount_dir=/run/image-recovery/mnt
root=$mount_dir/omarchy-root
mirror=/var/cache/omarchy/mirror/offline
[[ $(systemd-detect-virt --vm) =~ ^(qemu|kvm)$ ]]
[[ $(blkid -s UUID -o value "$device") == 51a18a79-7bde-4aeb-8895-181970407957 ]]
[[ -z $(lsblk -nro MOUNTPOINTS "$device" | tr -d '[:space:]') ]]
! pgrep -x pacman
masked_hooks=()
cleanup() {
  status=$?; set +e
  for hook in "${masked_hooks[@]}"; do rm -f "/etc/pacman.d/hooks/$hook"; done
  if mountpoint -q "$mount_dir"; then umount -R "$mount_dir"; fi
  exit "$status"
}
trap cleanup EXIT
mount -o compress-force=zstd:15 "$device" "$mount_dir"
python /run/image-recovery/prepare-tail-repair.py
cat >/run/image-recovery/pacman.conf <<EOF
[options]
Architecture = auto
CheckSpace
CacheDir = $mirror
SigLevel = Never
LocalFileSigLevel = Never
[offline]
Server = file://$mirror
EOF
for hook in 60-mkinitcpio-remove.hook 60-limine-mkinitcpio-remove-pre.hook 80-limine-efi-deploy.hook 90-limine-mkinitcpio-remove-post.hook 90-mkinitcpio-install.hook; do
  [[ ! -e /etc/pacman.d/hooks/$hook && ! -L /etc/pacman.d/hooks/$hook ]]
  ln -s /dev/null "/etc/pacman.d/hooks/$hook"
  masked_hooks+=("$hook")
done
rm -f "$root/var/lib/pacman/db.lck"
pacstrap -C /run/image-recovery/pacman.conf -c -G -M "$root" zbar zoxide zram-generator
pacman --root "$root" -Q | LC_ALL=C sort >/run/image-recovery/tail-repair/package-manifest-after.txt
cmp /run/image-recovery/baseline/package-manifest.txt /run/image-recovery/tail-repair/package-manifest-after.txt
pacman --root "$root" -Qk >/run/image-recovery/tail-repair/package-files-after.txt
printf '%s\n' REPAIR_COMPLETE >/run/image-recovery/tail-repair/status.txt
sync
