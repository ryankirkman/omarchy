#!/usr/bin/python3
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
root=Path('/run/image-recovery/mnt/omarchy-root'); mirror=Path('/var/cache/omarchy/mirror/offline');out=Path('/run/image-recovery/tail-repair')
expected={'zbar':'0.23.93-7','zoxide':'0.10.0-1','zram-generator':'1.2.1-1'}
if out.exists():raise SystemExit('requires fresh recovery evidence')
out.mkdir();(out/'original-db').mkdir()
claimed=set()
for d in (root/'var/lib/pacman/local').iterdir():
 if not d.is_dir() or d.name in {n+'-'+v for n,v in expected.items()}:continue
 text=(d/'files').read_text()
 if '%FILES%\n' in text:claimed.update(text.split('%FILES%\n',1)[1].split('\n\n',1)[0].splitlines())
plan=[]
for name,version in expected.items():
 archives=list(mirror.glob(name+'-'+version+'-*.pkg.tar.zst'))
 if len(archives)!=1:raise SystemExit('ambiguous exact archive '+name)
 archive=archives[0]
 names=subprocess.check_output(['bsdtar','-tf',str(archive)],text=True).splitlines()
 info=subprocess.check_output(['bsdtar','-q','-xOf',str(archive),'.PKGINFO'],text=True)
 fields={k.strip():v.strip() for line in info.splitlines() if '=' in line for k,v in [line.split('=',1)]}
 if fields.get('pkgname')!=name or fields.get('pkgver')!=version:raise SystemExit('archive identity mismatch '+name)
 (out/(name+'.PKGINFO')).write_text(info)
 mtree=subprocess.check_output(['bsdtar','-q','-xOf',str(archive),'.MTREE']);(out/(name+'.MTREE')).write_bytes(mtree)
 if '.INSTALL' in names:(out/(name+'.INSTALL')).write_bytes(subprocess.check_output(['bsdtar','-q','-xOf',str(archive),'.INSTALL']))
 db=root/'var/lib/pacman/local'/(name+'-'+version)
 if (db/'desc').stat().st_size!=0 or (db/'files').stat().st_size!=0:raise SystemExit('package no longer matches preserved malformed state '+name)
 files=[]
 for raw in names:
  relative=raw.removeprefix('./')
  if relative.startswith('.') or relative.endswith('/'):continue
  if relative.startswith('/') or '..' in Path(relative).parts:raise SystemExit('unsafe archive path')
  if relative in claimed:raise SystemExit('file owned by another installed package '+relative)
  file=root/relative
  if not file.parent.resolve().is_relative_to(root.resolve()):raise SystemExit('parent symlink escapes target '+relative)
  if file.exists() or file.is_symlink():
   if not file.is_file() and not file.is_symlink():raise SystemExit('unexpected file type '+relative)
   files.append({'path':relative,'kind':'symlink' if file.is_symlink() else 'file','sha256':None if file.is_symlink() else hashlib.sha256(file.read_bytes()).hexdigest(),'symlink':os.readlink(file) if file.is_symlink() else None})
  else:files.append({'path':relative,'kind':'missing'})
 plan.append({'package':name,'version':version,'archive':str(archive),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'db_directory':str(db),'files':files})
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
# All identities, ownership and path bounds passed before the first mutation.
for item in plan:
 source=Path(item['db_directory']);shutil.move(source,out/'original-db'/source.name)
 for file in item['files']:
  if file['kind']!='missing':(root/file['path']).unlink()
(out/'prepared.txt').write_text('Original malformed DB retained; only exact unowned archive paths removed for package-manager reinstallation.\n')
print(json.dumps({'prepared_packages':[p['package'] for p in plan],'replace_paths':sum(len(p['files']) for p in plan)},indent=2))
