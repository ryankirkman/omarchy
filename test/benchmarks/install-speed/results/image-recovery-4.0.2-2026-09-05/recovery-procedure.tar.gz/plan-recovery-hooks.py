#!/usr/bin/python3
"""Prepare a hook replay only for this interrupted all-install transaction."""
import fnmatch,hashlib,json,re,sys
from pathlib import Path
root,out=map(Path,sys.argv[1:])
masked={"60-mkinitcpio-remove.hook","60-limine-mkinitcpio-remove-pre.hook","80-limine-efi-deploy.hook","90-limine-mkinitcpio-remove-post.hook","90-mkinitcpio-install.hook"}
def sections(text):
 result=[]; current=None
 for original in text.splitlines():
  line=original.strip()
  if not line or line.startswith('#'):continue
  if line.startswith('[') and line.endswith(']'):
   current=(line[1:-1],{});result.append(current);continue
  if current is None:raise ValueError('data outside a section')
  key,sep,value=line.partition('=');current[1].setdefault(key.strip(),[]).append(value.strip() if sep else True)
 return result
def db_section(file,key):
 text=file.read_text();marker='%'+key+'%\n'
 if key=='FILES' and not text:return []
 if marker not in text:raise ValueError(f'{file} lacks {key}')
 return text.split(marker,1)[1].split('\n\n',1)[0].splitlines()
packages=set();paths=set()
expected_counts={name:int(count) for name,count in re.findall(r'^(\S+): (\d+) total files, \d+ missing files$',Path('/run/image-recovery/baseline/package-files.txt').read_text(),re.M)}
if len(expected_counts)!=941:raise ValueError('missing baseline package file counts')
for directory in sorted((root/'var/lib/pacman/local').iterdir()):
 if not directory.is_dir():continue
 name=db_section(directory/'desc','NAME')
 if len(name)!=1:raise ValueError('bad name')
 files=db_section(directory/'files','FILES')
 if len(files)!=expected_counts.get(name[0]):raise ValueError('file count differs from calibration: '+name[0])
 if not (directory/'mtree').stat().st_size:raise ValueError('empty mtree: '+name[0])
 packages.add(name[0]);paths.update(files)
if len(packages)!=941:raise ValueError('requires complete 941-package transaction')
log=Path('/run/image-recovery/interrupted-pacman.log').read_text()
logged=re.findall(r'\[ALPM\] installed (\S+) \(',log)
if len(logged)!=941 or set(logged)!=packages:raise ValueError('transaction log does not prove every completed package record')
if '[ALPM] transaction completed' in log:raise ValueError('unexpected transaction completion; review recovery manually')
paths=sorted(paths);packages=sorted(packages)
hooks={}
for directory in [root/'usr/share/libalpm/hooks',root/'etc/pacman.d/hooks']:
 if directory.is_dir():
  for file in directory.glob('*.hook'):hooks[file.name]=file
plan=[];skipped=[]
for name,file in sorted(hooks.items()):
 if name in masked:
  skipped.append({'name':name,'reason':'original upstream deferred boot hook mask'});continue
 if file.is_symlink() and str(file.readlink())=='/dev/null':
  skipped.append({'name':name,'reason':'installed hook mask'});continue
 text=file.read_text();parsed=sections(text)
 actions=[values for section,values in parsed if section=='Action']
 if len(actions)!=1:raise ValueError('requires exactly one action: '+name)
 action=actions[0]
 if action.get('When')!=['PostTransaction']:
  skipped.append({'name':name,'reason':'not PostTransaction'});continue
 selected=set()
 for section,trigger in parsed:
  if section!='Trigger' or 'Install' not in trigger.get('Operation',[]):continue
  if trigger.get('Type')==['Path']:possible=paths
  elif trigger.get('Type')==['Package']:possible=packages
  else:raise ValueError('unsupported trigger type '+name)
  patterns=trigger['Target']
  for value in possible:
   matched=False
   for pattern in patterns:
    negative=pattern.startswith('!')
    if fnmatch.fnmatchcase(value,pattern[1:] if negative else pattern):matched=not negative
   if matched:selected.add(value)
 if not selected:
  skipped.append({'name':name,'reason':'no Install trigger matches full transaction'});continue
 for dependency in action.get('Depends',[]):
  if dependency not in packages:raise ValueError('missing hook dependency '+dependency)
 if len(action.get('Exec',[]))!=1:raise ValueError('requires one Exec '+name)
 plan.append({'name':name,'source':str(file.relative_to(root)),'sha256':hashlib.sha256(text.encode()).hexdigest(),'exec':action['Exec'][0],'needs_targets':'NeedsTargets' in action,'targets':sorted(selected),'depends':action.get('Depends',[])})
result={'schema_version':1,'operation':'Install','package_count':len(packages),'package_file_paths':len(paths),'packages':packages,'masked_hooks':sorted(masked),'hook_order':'C lexical filename; target etc overrides target usr (the sole target override is masked, yielding the same effective hooks as the original empty live host override directory)','matching':'fnmatchcase for this source snapshot; slash matched by wildcards, ordered targets; later matching target overrides earlier','hooks':plan,'skipped':skipped}
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'planned_hooks':len(plan),'skipped_hooks':len(skipped),'package_count':len(packages),'path_count':len(paths)}))
