#!/usr/bin/python3
import gzip,hashlib,json,sys
from pathlib import Path
root,source_file,output=map(Path,sys.argv[1:])
raw=gzip.decompress(source_file.read_bytes())
if hashlib.sha256(raw).hexdigest()!='bb18e91d8dc81731d625ffbf29ba11bd43fe8b1cea655ac8967548e11aefd0d4':raise SystemExit('Archive checks digest mismatch')
source=json.loads(raw)
if source.get('complete') is not True or len(source['packages'])!=941:raise SystemExit('Incomplete source catalog')
problems=[];verified=[]
def section(file,key):
 text=file.read_text(); marker='%'+key+'%\n'
 if key=='FILES' and not text:return []
 if marker not in text:raise ValueError('missing '+key)
 return text.split(marker,1)[1].split('\n\n',1)[0].splitlines()
for reference in source['packages']:
 name,version=reference['name'],reference['version']
 db=root/'var/lib/pacman/local'/(name+'-'+version)
 try:
  fields={'name':section(db/'desc','NAME')[0],'version':section(db/'desc','VERSION')[0]}
  files=section(db/'files','FILES');canonical=''.join(p+'\n' for p in sorted(files)).encode()
  fields.update(file_count=len(files),file_list_sha256=hashlib.sha256(canonical).hexdigest(),mtree_sha256=hashlib.sha256((db/'mtree').read_bytes()).hexdigest(),install_scriptlet_present=(db/'install').exists(),install_sha256=hashlib.sha256((db/'install').read_bytes()).hexdigest() if (db/'install').exists() else None)
  differing={key:{'expected':reference[key],'actual':value} for key,value in fields.items() if reference[key]!=value}
  if len(set(files))!=len(files):differing['duplicate_files']=True
  if differing:problems.append({'package':name,'different':differing})
  else:verified.append(name)
 except Exception as error:problems.append({'package':name,'error':str(error)})
actual={p.name for p in (root/'var/lib/pacman/local').iterdir() if p.is_dir()}
expected={p['name']+'-'+p['version'] for p in source['packages']}
if actual!=expected:problems.append({'database_directory_difference':{'unexpected':sorted(actual-expected),'missing':sorted(expected-actual)}})
result={'schema_version':1,'status':'verified' if not problems else 'failed','source_checks_sha256':hashlib.sha256(raw).hexdigest(),'catalog_sha256':source['catalog_sha256'],'verified_package_count':len(verified),'expected_package_count':941,'fields':['NAME','VERSION','file count','canonical file-list SHA256','raw MTREE SHA256','INSTALL presence/SHA256'],'problems':problems}
output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if problems:raise SystemExit(1)
